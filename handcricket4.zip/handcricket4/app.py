from flask import Flask, render_template, request, redirect, url_for, session
import random

app = Flask(__name__)
app.secret_key = 'secret'


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/start', methods=['POST'])
def start():
    choice = request.form['choice']  # 'bat' or 'bowl'
    wickets = int(request.form['wickets'])  # 2, 5, or 10

    session['user_score'] = 0
    session['comp_score'] = 0
    session['user_first'] = (choice == 'bat')
    session['inning'] = 1
    session['is_user_batting'] = session['user_first']
    session['history'] = []
    session['game_over'] = False
    session['user_wickets'] = 0
    session['comp_wickets'] = 0
    session['total_wickets'] = wickets
    session['ball'] = 0
    session['over'] = 1

    return redirect(url_for('game'))


@app.route('/game', methods=['GET', 'POST'])
def game():
    if session.get('game_over'):
        return redirect(url_for('result'))

    message = ''
    if request.method == 'POST':
        user_choice = int(request.form['number'])
        comp_choice = random.randint(1, 6)
        out = user_choice == comp_choice

        ball = session['ball']
        over = session['over']

        if session['is_user_batting']:
            if out:
                session['user_wickets'] += 1
                message = f"You're OUT! You chose {user_choice}, computer chose {comp_choice}."
                if session['user_wickets'] >= session['total_wickets']:
                    session['inning'] += 1
                    session['is_user_batting'] = False
                    session['ball'] = 0
                    session['over'] = 1
                    if not session['user_first']:
                        session['game_over'] = True
            else:
                session['user_score'] += user_choice
                message = f"You scored {user_choice}. Computer chose {comp_choice}."
                if not session['user_first'] and session['inning'] == 2 and session['user_score'] > session['comp_score']:
                    session['game_over'] = True
        else:
            if out:
                session['comp_wickets'] += 1
                message = f"Computer is OUT! You chose {user_choice}, computer chose {comp_choice}."
                if session['comp_wickets'] >= session['total_wickets']:
                    session['inning'] += 1
                    session['is_user_batting'] = True
                    session['ball'] = 0
                    session['over'] = 1
                    if session['user_first']:
                        session['game_over'] = True
            else:
                session['comp_score'] += comp_choice
                message = f"Computer scored {comp_choice}. You chose {user_choice}."
                if session['user_first'] and session['inning'] == 2 and session['comp_score'] > session['user_score']:
                    session['game_over'] = True

        # Store ball in history before incrementing
        session['history'].append({
            'score': user_choice if session['is_user_batting'] else comp_choice,
            'batting': 'User' if session['is_user_batting'] else 'Computer',
            'over': session['over'],
            'ball': session['ball']
        })

        session['ball'] += 1
        if session['ball'] >= 6:
            session['ball'] = 0
            session['over'] += 1

    return render_template(
        'game.html',
        is_user_batting=session['is_user_batting'],
        user_score=session['user_score'],
        comp_score=session['comp_score'],
        inning=session['inning'],
        history=session['history'],
        message=message,
        user_wickets=session['user_wickets'],
        comp_wickets=session['comp_wickets'],
        total_wickets=session['total_wickets']
    )


@app.route('/result')
def result():
    user = session.get('user_score', 0)
    comp = session.get('comp_score', 0)

    if user > comp:
        result = "You WIN! 🎉"
    elif comp > user:
        result = "You LOSE! 😞"
    else:
        result = "It's a DRAW! 🤝"

    return render_template('result.html', user_score=user, comp_score=comp, result=result)


if __name__ == '__main__':
    app.run(debug=True)
